//
//  Bluetooth Service.swift
//  BabySavr
//
//  Created by yeyy on 5/22/24.
//

import Foundation
import CoreBluetooth
import UserNotifications

enum ConnectionStatus: String {
    case Connected
    case Disconnected
    case Scanning
    case Connecting
    case error
}
let hallSensorService: CBUUID = CBUUID(string: "4fafc201-1fb5-459e-8fcc-c5c9c331914b")
let hallSensorCharacteristic: CBUUID = CBUUID(string: "beb5483e-36e1-4688-b7f5-ea07361b26a8")
class BluetoothService: NSObject, ObservableObject {
    private var centralManager: CBCentralManager!
    var hallSensorPeripheral: CBPeripheral?
    @Published var peripheralStatus: ConnectionStatus = .Disconnected
    @Published var magnetValue: [Int] = [0, 0]
    @Published var TempValue=0
    @Published var Weight = 0
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    func scanForPeripherals() {
        peripheralStatus = .Scanning
        centralManager.scanForPeripherals(withServices: nil)
    }
}
extension BluetoothService: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            print("CB Powered On")
            scanForPeripherals()
        }
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        if peripheral.name == "Magnet Sensor" {
            print("Discovered \(peripheral.name ?? "no name")")
            hallSensorPeripheral = peripheral
            centralManager.connect(hallSensorPeripheral!)
            peripheralStatus = .Connecting
        }
    }
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheralStatus = .Connected
        peripheral.delegate = self
        peripheral.discoverServices([hallSensorService])
        centralManager.stopScan()
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        peripheralStatus = .Disconnected
    }
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        peripheralStatus = .error
        print(error?.localizedDescription ?? "no error")
    }
}
extension BluetoothService: CBPeripheralDelegate {
    //    func dataToInt(_ data: Data) -> Int {
    //      guard let bytes = data.withUnsafeBytes({ pointer in
    //        return pointer.baseAddress?.assumingMemoryBound(to: UInt8.self)
    //      }) else { return 0 }
    //
    //      var result: Int = 0
    //
    //      // Assuming little-endian byte order (adjust for big-endian)
    //      for i in 0..<data.count {
    //        result |= Int(bytes[i]) << (8 * (data.count - i - 1))
    //      }
    //
    //      return result
    //    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service in peripheral.services ?? [] {
            if service.uuid == hallSensorService {
                print("found service for \(hallSensorService)")
                peripheral.discoverCharacteristics([hallSensorCharacteristic], for: service)
            }
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        for characteristic in service.characteristics ?? [] {
            peripheral.setNotifyValue(true, for: characteristic)
            print("found characteristic, waiting on values.")
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if characteristic.uuid == hallSensorCharacteristic {
            guard let data = characteristic.value else { return }
            // Unpack data from the received bytes (adjust based on data types)
            TempValue = Int(data[0])+200
            Weight = Int(data[1])*9
        
        }
        if TempValue>100{
            let content = UNMutableNotificationContent()
            content.title = "Danger"
            content.body = "Your Child is in Danger!"
            content.sound = UNNotificationSound.defaultCritical
            
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
            
            let request = UNNotificationRequest(identifier: "reminderNotification", content: content, trigger: trigger)
            
            UNUserNotificationCenter.current().add(request) { error in
                if let error = error {
                    print("Error scheduling notification: \(error.localizedDescription)")
                } else {
                    print("Notification scheduled successfully")
                }
            }
        }
    }
}

