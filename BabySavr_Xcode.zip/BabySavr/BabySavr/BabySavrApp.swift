//
//  BabySavrApp.swift
//  BabySavr
//
//  Created by yeyy on 5/22/24.
//

import SwiftUI

@main
struct BabySavrApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
