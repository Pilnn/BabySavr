//
//  ContentView.swift
//  BabySavr
//
//  Created by yeyy on 5/22/24.
//

import SwiftUI

struct ContentView: View {
    let notify = NotificationHandler()

    @StateObject var service = BluetoothService()
    

    var body: some View {
        VStack {
            ZStack{
                //Rectangle().cornerRadius(15)
                    //.frame(width: 300, height: 50)
                //Rectangle().cornerRadius(15)
                  //  .frame(width: 280, height: 40).foregroundColor(.white)
                Text(service.peripheralStatus.rawValue)
                    .font(.title)//.foregroundColor(.black)
            }

            Spacer()
            HStack{
                Text("Temperature:").font(.largeTitle)
                Text("\(service.TempValue)")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                Text("°F").font(.largeTitle)
            }
            HStack{
                Text("Weight:").font(.largeTitle)
                Text("\(service.Weight)").font(.largeTitle).fontWeight(.bold)
                Text("g").font(.largeTitle)
            }
            Spacer()
            Button("Request permissions") {
                notify.askPermission()
            }
           
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
